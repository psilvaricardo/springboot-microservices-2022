package com.microservicesws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieDataMserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieDataMserviceApplication.class, args);
	}

}
